package com.kys.signal;

public enum Signal {
	
	MEMBER_JOIN_SUCCESS(1),MEMBER_JOIN_FAIL(0);
	
	public int getSignal ;
	
	Signal(int signal) {
		this.getSignal = signal;
	}

}
