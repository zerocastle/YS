package com.kys.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDao {

	DataSource dataSource;

	public MemberDao() {
		// TODO Auto-generated constructor stub
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
	// 회원가입
	public int joinOk(String name, String id, String pw, String address) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstm = null;
		String query = "insert into member values(?,?,?,?)";
		int signal = 0;
		try {
			connection = dataSource.getConnection();
			pstm = connection.prepareStatement(query);
			pstm.setString(1, name);
			pstm.setString(2, id);
			pstm.setString(3, pw);
			pstm.setString(4, address);
			signal = pstm.executeUpdate();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (connection != null)
					connection.close();
				if (pstm != null)
					pstm.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return signal;
	}

}
