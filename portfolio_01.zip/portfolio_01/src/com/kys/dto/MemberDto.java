package com.kys.dto;

public class MemberDto {

	private String name;
	private String id;
	private String pw;
	private String address;

	public MemberDto(String name, String id, String pw, String address) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.id = id;
		this.pw = pw;
		this.address = address;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
