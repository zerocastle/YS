package com.kys.ICommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface IMainAction {

	public void excute(HttpServletRequest request, HttpServletResponse response);

}
