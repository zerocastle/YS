package com.kys.ICommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kys.dao.MemberDao;
import com.kys.signal.Signal;

public class LJoinCommand implements IMainAction {

	@Override
	public void excute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		MemberDao dao = new MemberDao();
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String address = request.getParameter("address");
		int signal = dao.joinOk(name, id, pw, address);
		if(signal == Signal.MEMBER_JOIN_SUCCESS.getSignal) {
			System.out.println("success");
		}else
			System.out.println("fail");

	}

}
